/**
 * Name: Abdullah Yousaf
 * UCID: 30204056
 * Tutorial 01
 */

public class RecursiveShellSort {
    public static void shellSortRecursive(int[] array) {
        //created a public static method for the recursive shell sort for an array of integers

        int n = array.length;
        //this line is here to define the int and store the length of the array in 'n'

        int gap = 1;
        //here the gap variable is set to 1


        while (gap < n) {
            // while until gap is less than n

            gap = gap * 3;

        }
        //it will increase the gap by essentially multipling it by 3. Until it is larger than 'n'


        shellSortRecursiveHelper(array, n, gap / 3);
        // this will call the helper function

    }

    public static void shellSortRecursiveHelper(int[] array, int n, int gap) {
        // the helper function will performs the gap insertion sort


        if (gap > 0) {
            //it will continue to sort while there is a gap

            for (int i = gap; i < n; i++) {
                //the for loop in each element in the array starting from 'gap'

                int temp = array[i];
                //will store the element at index 'i'

                int j = i;
                // it will intialize j to i. comparing backwards.

                while (j >= gap && array[j - gap] > temp) {
                    array[j] = array[j - gap];
                    j -= gap;
                    //decreases j by gap to continue checking earlier elements

                }
                array[j] = temp;
                //this will reduce the gap for the next pass.

            }
            shellSortRecursiveHelper(array, n,gap / 3);

        }
    }



    public static void main(String[] args) {

        //input array to the recursive shell sort
        int[] arrayRecursive = {9, 8, 3, 7, 5, 6, 4, 1};

        shellSortRecursive(arrayRecursive);
        // calls the shellSortRecursive method on the array


        System.out.println("Array sorted using the recursive formula:");
        //print statement that will print the message onto the console.

        printArray(arrayRecursive);
        //this will call the printArray to print the sorted array

    }


        public static void printArray(int[] array) {
            //method to print elements of an array

            for (int num : array) {
                System.out.print(num + " ");
                //This prints each number in the array and it will have a space

            }
            System.out.println();
            //line is here to print a newline character.

        }


}
