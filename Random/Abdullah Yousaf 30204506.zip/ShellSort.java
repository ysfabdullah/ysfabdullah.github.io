/**
 * Name: Abdullah Yousaf
 * UCID: 30204056
 * Tutorial 01
 */


public class ShellSort {
    //This is a public class named ShellSort

    //Iterative Shell Sort using novel gap sequence
    public static void shellSortIterative(int[] array) {
        //created a public static method for the iterative shell sort for an array of integers

        int n = array.length;
        //this line is here to define the int and store the length of the array in 'n'

        int gap = 1;
        //here the gap variable is set to 1

        while (gap < n) {
            // while until gap is less than n
            gap = gap * 3;

        }
        //it will increase the gap by essentially multipling it by 3. Until it is larger than 'n'

        shellSortIterativeHelper(array, n, gap / 3);
        // this will call the helper function
    }


    public static void shellSortIterativeHelper(int[] array, int n, int gap) {
        // the helper function will performs the gap insertion sort


        while (gap > 0) {
            //it will continue to sort while there is a gap

            for (int i = gap; i < n; i++) {
                //the for loop in each element in the array starting from 'gap'

                int temp = array[i];
                //will store the element at index 'i'
                int j = i;
                // it will intialize j to i. comparing backwards.
                while (j >= gap && array[j - gap] > temp) {
                    array[j] = array[j - gap];
                    j -= gap;
                    //decreases j by gap to continue checking earlier elements
                }
                array[j] = temp;
            }
            gap /= 3;
            //this will reduce the gap for the next pass.
        }
    }


    // Recursive Shell sort using novel gap sequence

    public static void main(String[] args) {
        //this is the main method to run the code

        //input array to iterative shell sort
        int [] arrayIterative= {9,8,3,7,5,6,4,1};



        shellSortIterative(arrayIterative);
        // calls the shellSortIterative method on the array

        System.out.println("Array sorted using the iterative formula:");
        //print statement that will print the message onto the console.

        printArray(arrayIterative);
        //this will call the printArray to print the sorted array

    }


    public static void printArray(int[] array) {
        //method to print elements of an array
        for (int num : array) {
            System.out.print(num + " ");
            //This prints each number in the array and it will have a space
        }
        System.out.println();
        //line is here to print a newline character.
    }

}

